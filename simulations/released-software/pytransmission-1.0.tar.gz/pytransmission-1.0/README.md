pytransmission
==============

[![Build Status](https://travis-ci.org/mmadsen/pytransmission.svg?branch=master)](https://travis-ci.org/mmadsen/pytransmission)

Common code for cultural transmission models in Python, used by Mark E. Madsen in research simulations.  
