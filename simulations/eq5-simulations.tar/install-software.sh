#!/bin/bash

# copy the ctmixtures and pytransmission src tarballs to /home/sgeadmin/software, which is NFS mounted
# copy this script to /home/sgeadmin/software as install-software.sh
# from starcluster master, do:  ssh <cluster>-node001 "/home/sgeadmin/software/install-software.sh"


cd /home/sgeadmin/software
tar zxvf ctmixtures-2.4.tar.gz
cd ctmixtures-2.4
pip install -r requirements.txt
python setup.py install
cd ..
tar zxvf pytransmission-1.0.tar.gz
cd pytransmission-1.0
pip install -r requirements.txt
python setup.py install
cd ..
