#!/bin/bash

ctmixtures-priorsampler-runbuilder.py --experiment equifinality-3 --simprefix /usr/local/anaconda/bin --expconfig expconfig/neutral-priors.json --confprefix /home/sgeadmin --configuration conf/equifinality-allneutral.json --parallelism 250 --numsims 25000 --model neutral
ctmixtures-priorsampler-runbuilder.py --experiment equifinality-3 --simprefix /usr/local/anaconda/bin --expconfig expconfig/conformist-mixture-priors.json --confprefix /home/sgeadmin --configuration conf/equifinality-conformism.json --parallelism 250 --numsims 25000 --model conformist
ctmixtures-priorsampler-runbuilder.py --experiment equifinality-3 --simprefix /usr/local/anaconda/bin --expconfig expconfig/conformist-mixture-priors.json --confprefix /home/sgeadmin --configuration conf/equifinality-anticonformism.json --parallelism 250 --numsims 25000 --model conformist
